﻿using ativ1forn.Data;
using ativ1forn.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ativ1forn.Controllers
{
    public class FornecedoresController : Controller
    {
        private readonly AppCont _appCont;

        public FornecedoresController(AppCont appCont)
        {
            _appCont = appCont;
        }

        [HttpGet]
        public IActionResult Index()
        // informaçoes abaixo é sobre o comando apartir da var alltasks// no index clica com o botao direito e add exbicao e tem que ter o mesmo nome que a action
        {   //acesso as tabelas //qual tabela que foi escolhida //e o que vc quer q faça
            var allTasks = _appCont.Fornecedores.ToList();
            return View(allTasks);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var Fornecedores = await _appCont.Fornecedores
                .FirstOrDefaultAsync(x => x.Id == id);

            if (Fornecedores == null)
            {
                return BadRequest();
            }

            return View(Fornecedores);

        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Create(
            fornecedores Fornecedor)
        {
            if (ModelState.IsValid)
            {
                _appCont.Add(Fornecedor);
                await _appCont.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(Fornecedor);

        }

        [HttpGet]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var Fornecedores = await _appCont.Fornecedores.FindAsync(id);

            if (Fornecedores == null)
            {
                return BadRequest();
            }

            return View(Fornecedores);

        }
        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Edit(
            int? id,
            fornecedores Fornecedores)
        {
            if (id == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _appCont.Update(Fornecedores);
                await _appCont.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(Fornecedores);

        }

        [HttpGet]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var Fornecedores = await _appCont.Fornecedores.FirstOrDefaultAsync(x => x.Id == id);

            if (Fornecedores == null)
            {
                return NotFound();
            }

            return View(Fornecedores);

        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var Fornecedores = await _appCont.Fornecedores.FindAsync(id);
            _appCont.Fornecedores.Remove(Fornecedores);
            await _appCont.SaveChangesAsync();
            return RedirectToAction("Index");
        }
    }
}