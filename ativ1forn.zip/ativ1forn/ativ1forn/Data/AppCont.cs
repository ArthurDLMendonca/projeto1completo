﻿using Microsoft.EntityFrameworkCore;
using ativ1forn.Models;

namespace ativ1forn.Data
{
    public class AppCont : DbContext
    {

        public AppCont(DbContextOptions<AppCont> options) : base(options)
        {

        }


        public DbSet<fornecedores> Fornecedores { get; set; }
    }
}

