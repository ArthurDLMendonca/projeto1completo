﻿using ativ1forn.Models;

namespace ativ1forn.Data
{
    public class AppDBInitializer
    { 
     public static void Seed(IApplicationBuilder applicationBuilder)
    {
        using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
        {
            var context = serviceScope.ServiceProvider.GetService<AppCont>();
            context.Database.EnsureCreated();

            //criar Tarefas
            if (!context.Fornecedores.Any())
            {
                context.Fornecedores.AddRange(new List<fornecedores>()
                {

                        new fornecedores()
                        {
                            RazaoSocial = "Missao Kids",
                            NomeFantasia = "Missao Kids",
                            Email = "missaokids@gmail.com",
                            Telefone = "(16)9999-9999",
                            Rua = "Av. Dom Pedro I",
                            Numero = "468",
                            Bairro = "Ipiranga",
                            Cidade = "Ribeirao Preto",
                            Estado = "Sao Paulo",
                            CEP = "00000-000",
                            NomeContato = "Arthur Mendonca"
                        },
                        new fornecedores()
                            {
                              RazaoSocial = "Estrela do Bebê Ltda",
                              NomeFantasia = "Estrela do Bebê",
                              Email = "contato@estreladobebe.com",
                              Telefone = "(11) 8888-8888",
                              Rua = "Rua das Flores",
                              Numero = "150",
                              Bairro = "Jardim Primavera",
                              Cidade = "São Paulo",
                              Estado = "São Paulo",
                              CEP = "12345-678",
                              NomeContato = "Douglas Costa"
                            },

                            new fornecedores()
                            {
                              RazaoSocial = "Sonho Infantil Comércio",
                              NomeFantasia = "Sonho Infantil",
                              Email = "vendas@sonhoinfantil.com.br",
                              Telefone = "(21) 7777-7777",
                              Rua = "Rua do Brincar",
                              Numero = "230",
                              Bairro = "Vila Alegre",
                              Cidade = "Rio de Janeiro",
                              Estado = "Rio de Janeiro",
                              CEP = "98765-432",
                              NomeContato = "Carlos Silva"
                            }


                    });
                context.SaveChanges();
            }
        }
    }
}
}